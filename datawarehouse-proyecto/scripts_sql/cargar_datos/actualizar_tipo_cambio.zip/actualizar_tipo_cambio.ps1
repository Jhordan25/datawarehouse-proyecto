$token = "apis-token-16347.9AnB04o4ecBS6W9aqQRS7236UDamZSZC"
$meses = @(6, 7)
$year = (Get-Date).Year
$hoy = Get-Date -Format "yyyy-MM-dd"

foreach ($mes in $meses) {
    $url = "https://api.apis.net.pe/v2/sunat/tipo-cambio?month=$mes&year=$year"
    $response = Invoke-RestMethod -Uri $url -Headers @{Authorization="Bearer $token"}
    
    foreach ($registro in $response) {
        if (
            $registro.fecha -le $hoy -and
            $registro.precioCompra -ne $null -and
            $registro.precioVenta -ne $null
        ) {
            $compra = [double]::Parse($registro.precioCompra.ToString(), [System.Globalization.CultureInfo]::InvariantCulture)
            $venta = [double]::Parse($registro.precioVenta.ToString(), [System.Globalization.CultureInfo]::InvariantCulture)
            $fecha = $registro.fecha
            $moneda = $registro.moneda

            $sql = @"
IF NOT EXISTS (SELECT 1 FROM TipoCambioSunat WHERE Fecha = '$fecha')
BEGIN
    INSERT INTO TipoCambioSunat (Fecha, Compra, Venta, Moneda)
    VALUES ('$fecha', $compra, $venta, '$moneda')
END
"@

            Invoke-Sqlcmd -Query $sql -ServerInstance "DESKTOP-8GUFU2S\SQL2022" -Database "DBCostaDelSol"
        }
    }
}

